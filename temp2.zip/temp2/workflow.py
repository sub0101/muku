from flytekit import task, workflow

@task
def add_numbers(a: int, b: int) -> int:
    return a + b

@workflow
def sum_workflow(a: int, b: int) -> int:
    return add_numbers(a=a, b=b)

if __name__ == "__main__":
    # Local test run
    result = sum_workflow(a=3, b=5)
    print(f"Sum of 3 and 5 is: {result}")
