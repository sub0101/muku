import flytekit
from flytekit import task, workflow, Resources, ImageSpec
from flytekitplugins.spark import Spark
from flytekit.types.structured.structured_dataset import StructuredDataset
from typing_extensions import Annotated
from flytekit import kwtypes

# 🐳 ImageSpec
custom_image = ImageSpec(
    name="spark-minio-image",
    python_version="3.9",
    registry="docker.io/sursin01",  # Replace with your DockerHub if needed
    packages=["flytekitplugins-spark", "pandas", "pyarrow"],
)

columns = kwtypes(name=str, age=int)

# 🧠 Spark task to read from MinIO, transform, and write back
@task(
    task_config=Spark(
        spark_conf={
            "spark.driver.memory": "1000M",
            "spark.executor.memory": "1000M",
            "spark.executor.cores": "1",
            "spark.executor.instances": "2",
            "spark.hadoop.fs.s3a.access.key": "minioadmin",
            "spark.hadoop.fs.s3a.secret.key": "minioadmin",
            "spark.hadoop.fs.s3a.endpoint": "http://minio.flyte.svc.cluster.local:9000",
            "spark.hadoop.fs.s3a.path.style.access": "true",
            "spark.hadoop.fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
        }
    ),
    container_image=custom_image,
    limits=Resources(mem="2Gi"),
)
def process_minio_data() -> Annotated[StructuredDataset, kwtypes(**{
    "Username": str,
    "Login email": str,
    "Identifier": str,
    "First name": str,
    "Last name": str,
    "Full name": str
})]:
    spark = flytekit.current_context().spark_session

    # Read CSV with semicolon delimiter
    input_path = "s3a://mybucket/sample.csv"
    df = spark.read.option("header", True).option("delimiter", ";").csv(input_path)

    # Add full name column
    df = df.withColumn("Full name", df["First name"].cast("string") + spark.functions.lit(" ") + df["Last name"].cast("string"))

    # Optional: Save output
    output_path = "s3a://mybucket/output/with_fullname.csv"
    df.write.mode("overwrite").option("header", True).option("delimiter", ";").csv(output_path)

    return StructuredDataset(dataframe=df)

@workflow
def minio_read_transform_write() -> Annotated[StructuredDataset, columns]:
    return process_minio_data()

if __name__ == "__main__":
    print("Running workflow...")
    print(minio_read_transform_write())
