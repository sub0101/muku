import os
from flytekit import task, workflow, ImageSpec
from flytekitplugins.spark import Spark

# Configuration - replace these with your actual values or environment variables
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "http://localhost:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "minioadmin")

INPUT_PATH = "s3a://logs/sample.csv"
OUTPUT_PATH = "s3a://mybucket2/processed/"

# Docker image spec - ensure pyspark and required hadoop aws jars included
spark_image = ImageSpec(
    name="spark-minio-job",
    python_version="3.9",
    packages=["pyspark", "pandas", "pyarrow"],  # Add all pip packages here
    builder_commands=[
        "mkdir -p /opt/spark/jars",
        "wget https://repo1.maven.org/maven2/org/apache/hadoop/hadoop-aws/3.3.4/hadoop-aws-3.3.4.jar -O /opt/spark/jars/hadoop-aws-3.3.4.jar",
        "wget https://repo1.maven.org/maven2/com/amazonaws/aws-java-sdk-bundle/1.12.723/aws-java-sdk-bundle-1.12.723.jar -O /opt/spark/jars/aws-java-sdk-bundle-1.12.723.jar",
    ],
)

@task(
    task_config=Spark(
        spark_conf={
            "spark.hadoop.fs.s3a.endpoint": MINIO_ENDPOINT,
            "spark.hadoop.fs.s3a.access.key": MINIO_ACCESS_KEY,
            "spark.hadoop.fs.s3a.secret.key": MINIO_SECRET_KEY,
            "spark.hadoop.fs.s3a.path.style.access": "true",
            "spark.hadoop.fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
            "spark.hadoop.fs.s3a.connection.ssl.enabled": "false",
            "spark.driver.extraClassPath": "/opt/spark/jars/*",
            "spark.executor.extraClassPath": "/opt/spark/jars/*",
            "spark.app.name": "MinioSparkExample",
            "spark.executor.instances": "1",
            "spark.executor.memory": "512m",
            "spark.executor.cores": "1",
            "spark.driver.memory": "512m",
        }
    ),
    container_image=spark_image,
)
def process_minio_data(input_path: str, output_path: str) -> str:
    spark = current_context().spark_session

    # Read CSV with header and infer schema
    df = spark.read.csv(input_path, header=True, inferSchema=True)

    # Create 'Full name' by concatenating 'First name' and 'Last name'
    processed_df = df.withColumn("Full name", concat_ws(" ", df["First name"], df["Last name"]))

    # Drop the original 'First name' and 'Last name' columns
    processed_df = processed_df.drop("First name", "Last name")

    # Write the result as parquet to the output path (overwrite mode)
    processed_df.write.mode("overwrite").parquet(output_path)

    return f"Processed data written to {output_path}"

@workflow
def minio_spark_workflow() -> str:
    return process_minio_data(INPUT_PATH, OUTPUT_PATH)

if __name__ == "__main__":
    print(minio_spark_workflow())