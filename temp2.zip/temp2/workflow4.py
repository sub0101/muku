import os
import pandas as pd
import boto3
from flytekit import task, workflow ,ImageSpec

MINIO_ENDPOINT = "http://localhost:9000"
MINIO_ACCESS_KEY = "minioadmin"
MINIO_SECRET_KEY = "minioadmin"
BUCKET_NAME = "mybucket"
FILE_NAME = "sample.csv"
custom_image = ImageSpec(
    python_version="3.9", registry="docker.io/sursin01", packages=["pandas","boto3"]
)

@task(container_image=custom_image)
def create_and_upload_csv() -> str:
    # Create dataframe
    df = pd.DataFrame({
        "name": ["Alice", "Bob"],
        "age": [25, 30]
    })

    df.to_csv(FILE_NAME, index=False)

    s3 = boto3.client(
        "s3",
        endpoint_url=MINIO_ENDPOINT,
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
    )

    # Create bucket if needed
    try:
        s3.create_bucket(Bucket=BUCKET_NAME)
    except s3.exceptions.BucketAlreadyOwnedByYou:
        pass
    except s3.exceptions.BucketAlreadyExists:
        pass

    s3.upload_file(FILE_NAME, BUCKET_NAME, FILE_NAME)

    os.remove(FILE_NAME)

    return f"File '{FILE_NAME}' uploaded successfully to bucket '{BUCKET_NAME}'"

@workflow
def minio_upload_wf() -> str:
    return create_and_upload_csv()

if __name__ == "__main__":
    print(minio_upload_wf())
