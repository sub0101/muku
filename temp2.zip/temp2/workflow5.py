import flytekit
import pandas as pd
from flytekit import task, workflow, Resources, ImageSpec, kwtypes
from flytekit.types.structured.structured_dataset import StructuredDataset
from flytekitplugins.spark import Spark
from typing_extensions import Annotated

# 📦 Build a custom image if needed and use it here
# Replace with your DockerHub or private registry if not using ghcr.io
custom_image = ImageSpec(
    name="spark-pandas-image",
    python_version="3.9",
    registry="docker.io/sursin01",  # Or use 'localhost:30000' for demo cluster
    packages=["flytekitplugins-spark", "pandas", "pyarrow"],
)

# 👇 StructuredDataset schema definition
columns = kwtypes(name=str, age=int)

# 🚀 Spark task to return StructuredDataset
@task(
    task_config=Spark(
        spark_conf={
            "spark.driver.memory": "1000M",
            "spark.executor.memory": "1000M",
            "spark.executor.cores": "1",
            "spark.executor.instances": "2",
            "spark.driver.cores": "1",
        }
    ),
    container_image=custom_image,
    limits=Resources(mem="2Gi"),
)
def generate_data() -> Annotated[StructuredDataset, columns]:
    spark = flytekit.current_context().spark_session
    df = spark.createDataFrame(
        [("Alice", 25), ("Bob", 30), ("Charlie", 35)],
        ["name", "age"]
    )
    return StructuredDataset(dataframe=df)

# 🧮 Regular task consuming it as Pandas
@task(container_image=custom_image)
def compute_sum(sd: Annotated[StructuredDataset, columns]) -> int:
    df: pd.DataFrame = sd.open(pd.DataFrame).all()
    return int(df["age"].sum())

# 🧬 Workflow connecting Spark → Pandas
@workflow
def spark_to_pandas_flow() -> int:
    spark_df = generate_data()
    return compute_sum(sd=spark_df)

# 🧪 Local run
if __name__ == "__main__":
    print(spark_to_pandas_flow())
