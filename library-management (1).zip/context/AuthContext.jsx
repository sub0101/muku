"use client"

import { createContext, useState } from "react"

export const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)

  const login = (userData) => {
    setUser(userData)
    // Store user data in local storage or cookies
  }

  const logout = () => {
    setUser(null)
    // Remove user data from local storage or cookies
  }

  const value = { user, login, logout }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

