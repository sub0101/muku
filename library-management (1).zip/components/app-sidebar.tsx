"use client"

import { Book, BookCopy, BookOpen, Home, Library, Settings, Users } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarRail,
} from "@/components/ui/sidebar"

const navigation = [
  {
    title: "Overview",
    links: [
      { title: "Dashboard", icon: Home, href: "/" },
      { title: "Books", icon: Book, href: "/books" },
      { title: "Members", icon: Users, href: "/members" },
    ],
  },
  {
    title: "Library",
    links: [
      { title: "Borrowing", icon: BookCopy, href: "/borrowing" },
      { title: "Returns", icon: BookOpen, href: "/returns" },
    ],
  },
  {
    title: "System",
    links: [{ title: "Settings", icon: Settings, href: "/settings" }],
  },
]

export function AppSidebar() {
  const pathname = usePathname()

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg">
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <Library className="size-4" />
                </div>
                <div className="flex flex-col gap-0.5">
                  <span className="font-semibold">Library System</span>
                  <span className="text-xs">Management Portal</span>
                </div>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarHeader>
        <SidebarContent>
          {navigation.map((group) => (
            <SidebarGroup key={group.title}>
              <SidebarGroupLabel>{group.title}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {group.links.map((link) => (
                    <SidebarMenuItem key={link.href}>
                      <SidebarMenuButton asChild isActive={pathname === link.href}>
                        <Link href={link.href}>
                          <link.icon className="mr-2 h-4 w-4" />
                          {link.title}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}
        </SidebarContent>
        <SidebarRail />
      </Sidebar>
    </SidebarProvider>
  )
}

