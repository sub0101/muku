"use client"

import { useContext } from "react"
import { Link } from "react-router-dom"
import { AuthContext } from "../context/AuthContext"
import "./Navbar.css"

export default function Navbar() {
  const { user, logout } = useContext(AuthContext)

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          Library System
        </Link>

        <div className="navbar-links">
          <Link to="/books">Books</Link>
          {user && <Link to="/my-books">My Books</Link>}
          {user?.isAdmin && <Link to="/admin">Admin</Link>}
        </div>

        <div className="navbar-auth">
          {user ? (
            <>
              <span className="user-name">{user.name}</span>
              <button onClick={logout} className="btn btn-secondary">
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="btn btn-primary">
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  )
}

