import { BookOpen, Users } from "lucide-react"
import RecentActivities from "../components/RecentActivities"
import PopularBooks from "../components/PopularBooks"
import { Card } from "../components/ui/card"

function Dashboard() {
  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <div className="flex flex-row items-center justify-between p-6 pb-2">
            <h3 className="text-sm font-medium">Total Books</h3>
            <BookOpen className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="p-6 pt-0">
            <div className="text-2xl font-bold">2,543</div>
            <p className="text-xs text-muted-foreground">+180 from last month</p>
          </div>
        </Card>
        <Card>
          <div className="flex flex-row items-center justify-between p-6 pb-2">
            <h3 className="text-sm font-medium">Active Members</h3>
            <Users className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="p-6 pt-0">
            <div className="text-2xl font-bold">1,234</div>
            <p className="text-xs text-muted-foreground">+42 from last month</p>
          </div>
        </Card>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold">Recent Activities</h3>
            <p className="text-sm text-muted-foreground">Latest library activities and transactions</p>
            <div className="mt-6">
              <RecentActivities />
            </div>
          </div>
        </Card>
        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold">Popular Books</h3>
            <p className="text-sm text-muted-foreground">Most borrowed books this month</p>
            <div className="mt-6">
              <PopularBooks />
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

export default Dashboard

