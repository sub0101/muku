import { Progress } from "./ui/progress"

const books = [
  {
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    cover: "/placeholder.svg?height=48&width=32",
    borrowCount: 42,
    maxBorrows: 50,
  },
  {
    title: "1984",
    author: "George Orwell",
    cover: "/placeholder.svg?height=48&width=32",
    borrowCount: 38,
    maxBorrows: 50,
  },
  {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    cover: "/placeholder.svg?height=48&width=32",
    borrowCount: 35,
    maxBorrows: 50,
  },
]

function PopularBooks() {
  return (
    <div className="space-y-4">
      {books.map((book, index) => (
        <div key={index} className="flex items-center gap-4">
          <img src={book.cover || "/placeholder.svg"} alt={book.title} className="w-8 h-12 rounded-sm object-cover" />
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{book.title}</p>
            <p className="text-sm text-muted-foreground">{book.author}</p>
          </div>
          <div className="w-24">
            <Progress value={(book.borrowCount / book.maxBorrows) * 100} />
          </div>
        </div>
      ))}
    </div>
  )
}

export default PopularBooks

