import { Avatar } from "./ui/avatar"

const activities = [
  {
    user: {
      name: "John Doe",
      image: "/placeholder.svg?height=32&width=32",
      initials: "JD",
    },
    action: "borrowed",
    book: "The Great Gatsby",
    timestamp: "2 minutes ago",
  },
  {
    user: {
      name: "Jane Smith",
      image: "/placeholder.svg?height=32&width=32",
      initials: "JS",
    },
    action: "returned",
    book: "1984",
    timestamp: "1 hour ago",
  },
  {
    user: {
      name: "Mike Johnson",
      image: "/placeholder.svg?height=32&width=32",
      initials: "MJ",
    },
    action: "borrowed",
    book: "To Kill a Mockingbird",
    timestamp: "3 hours ago",
  },
]

function RecentActivities() {
  return (
    <div className="space-y-4">
      {activities.map((activity, index) => (
        <div key={index} className="flex items-center gap-4">
          <Avatar>
            <img src={activity.user.image || "/placeholder.svg"} alt={activity.user.name} />
            <span className="avatar-fallback">{activity.user.initials}</span>
          </Avatar>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{activity.user.name}</p>
            <p className="text-sm text-muted-foreground">
              {activity.action} "{activity.book}"
            </p>
          </div>
          <div className="text-sm text-muted-foreground">{activity.timestamp}</div>
        </div>
      ))}
    </div>
  )
}

export default RecentActivities

